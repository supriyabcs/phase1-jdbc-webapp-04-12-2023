package com.simplilearn.webapp.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {
	

	// data source properties
		private final String DB_URL = "jdbc:mysql://localhost:3306/estore_zone_db";
		private final String DB_USR = "newdevuser";
		private final String DB_PAS = "DevUser!74";

		Connection connection = null;
		Statement statment = null;
		
		public void initConnection() {
			
		
			try {
				// step1 : Register Driver (optional)
				Class.forName("com.mysql.cj.jdbc.Driver");
				

				// step2 : Create a connection
				connection = DriverManager.getConnection(DB_URL, DB_USR, DB_PAS);
				
				// step3 : Create a statement
				statment = connection.createStatement();
				
				// step4 : Execute query
				String query = "";
				

			} catch (ClassNotFoundException e) {
				System.out.println("Exception Occured ::: " + e.getClass());
			} catch (SQLException e) {
				System.out.println("Exception Occured ::: " + e.getClass());
			}
		}
}
			
			
			
			

		
		
		



